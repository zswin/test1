create definer = erp@`%` event evt_test
  on schedule
    every '1' HOUR
      starts '2016-06-06 19:22:47'
  enable
do
  BEGIN  
    DECLARE v char(20);
    
    SET v = convert(now(), char(20));
		insert into t3(c1) values(v);
END;

